<button class="button-toggle-menu">
    <i class="mdi mdi-menu"></i>
</button>
