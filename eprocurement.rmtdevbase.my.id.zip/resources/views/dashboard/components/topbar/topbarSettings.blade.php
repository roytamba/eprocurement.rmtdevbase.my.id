<li class="d-none d-sm-inline-block">
    <a class="nav-link" data-bs-toggle="offcanvas" href="#theme-settings-offcanvas">
        <i class="ri-settings-3-line font-22"></i>
    </a>
</li>