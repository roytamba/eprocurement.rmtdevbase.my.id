<li class="d-none d-sm-inline-block">
    <div class="nav-link" id="light-dark-mode" data-bs-toggle="tooltip" data-bs-placement="left" title="Theme Mode">
        <i class="ri-moon-line font-22"></i>
    </div>
</li>
