<button class="navbar-toggle" data-bs-toggle="collapse" data-bs-target="#topnav-menu-content">
    <div class="lines">
        <span></span>
        <span></span>
        <span></span>
    </div>
</button>
