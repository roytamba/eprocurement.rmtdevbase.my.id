<li class="d-none d-md-inline-block">
    <a class="nav-link" href="" data-toggle="fullscreen">
        <i class="ri-fullscreen-line font-22"></i>
    </a>
</li>
