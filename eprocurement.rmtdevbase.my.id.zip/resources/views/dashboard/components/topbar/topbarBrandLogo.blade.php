<div class="logo-topbar">
    <!-- Logo light -->
    <a href="index.html" class="logo-light">
        <span class="logo-lg">
            <img src="{{ asset('admin/images/logo.png') }}" alt="logo">
        </span>
        <span class="logo-sm">
            <img src="{{ asset('admin/images/logo-sm.png') }}" alt="small logo">
        </span>
    </a>

    <!-- Logo Dark -->
    <a href="index.html" class="logo-dark">
        <span class="logo-lg">
            <img src="{{ asset('admin/images/logo-dark.png') }}" alt="dark logo">
        </span>
        <span class="logo-sm">
            <img src="{{ asset('admin/images/logo-dark-sm.png') }}" alt="small logo">
        </span>
    </a>
</div>
