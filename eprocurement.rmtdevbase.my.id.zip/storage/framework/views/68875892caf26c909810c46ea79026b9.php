<li class="d-none d-md-inline-block">
    <a class="nav-link" href="" data-toggle="fullscreen">
        <i class="ri-fullscreen-line font-22"></i>
    </a>
</li>
<?php /**PATH D:\Project\My Project\laravel\eprocurement.rmtdevbase.my.id\resources\views/dashboard/components/topbar/fullscreen.blade.php ENDPATH**/ ?>