<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH D:\Project\My Project\laravel\eprocurement.rmtdevbase.my.id\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/header.blade.php ENDPATH**/ ?>