<li class="dropdown d-lg-none">
    <a class="nav-link dropdown-toggle arrow-none" data-bs-toggle="dropdown" href="#" role="button"
        aria-haspopup="false" aria-expanded="false">
        <i class="ri-search-line font-22"></i>
    </a>
    <div class="dropdown-menu dropdown-menu-animated dropdown-lg p-0">
        <form class="p-3">
            <input type="search" class="form-control" placeholder="Search ..." aria-label="Recipient's username">
        </form>
    </div>
</li>
<?php /**PATH D:\Project\My Project\laravel\eprocurement.rmtdevbase.my.id\resources\views/dashboard/components/topbar/recepientSearch.blade.php ENDPATH**/ ?>