<button class="navbar-toggle" data-bs-toggle="collapse" data-bs-target="#topnav-menu-content">
    <div class="lines">
        <span></span>
        <span></span>
        <span></span>
    </div>
</button>
<?php /**PATH D:\Project\My Project\laravel\eprocurement.rmtdevbase.my.id\resources\views/dashboard/components/topbar/horizontalToggle.blade.php ENDPATH**/ ?>