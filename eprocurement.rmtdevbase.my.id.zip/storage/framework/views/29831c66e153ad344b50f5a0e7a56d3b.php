<div class="navbar-custom">
    <div class="topbar container-fluid">
        <div class="d-flex align-items-center gap-lg-2 gap-1">

            <!-- Topbar Brand Logo -->
            <?php echo $__env->make('dashboard.components.topbar.topbarBrandLogo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Sidebar Menu Toggle Button -->
            <?php echo $__env->make('dashboard.components.topbar.topbarToggle', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Horizontal Menu Toggle Button -->
            <?php echo $__env->make('dashboard.components.topbar.horizontalToggle', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Topbar Search Form -->
            <?php echo $__env->make('dashboard.components.topbar.topbarSearch', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

        <ul class="topbar-menu d-flex align-items-center gap-3">
            
            <?php echo $__env->make('dashboard.components.topbar.recepientSearch', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php echo $__env->make('dashboard.components.topbar.languageDropdown', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php echo $__env->make('dashboard.components.topbar.notification', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php echo $__env->make('dashboard.components.topbar.topbarSettings', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php echo $__env->make('dashboard.components.topbar.themeMode', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php echo $__env->make('dashboard.components.topbar.fullscreen', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php echo $__env->make('dashboard.components.topbar.topbarAccount', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </ul>
    </div>
</div>
<?php /**PATH D:\Project\My Project\laravel\eprocurement.rmtdevbase.my.id\resources\views/dashboard/components/topbar/topbar.blade.php ENDPATH**/ ?>