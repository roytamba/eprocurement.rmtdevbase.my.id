<li class="d-none d-sm-inline-block">
    <div class="nav-link" id="light-dark-mode" data-bs-toggle="tooltip" data-bs-placement="left" title="Theme Mode">
        <i class="ri-moon-line font-22"></i>
    </div>
</li>
<?php /**PATH D:\Project\My Project\laravel\eprocurement.rmtdevbase.my.id\resources\views/dashboard/components/topbar/themeMode.blade.php ENDPATH**/ ?>