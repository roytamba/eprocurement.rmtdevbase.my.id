<?php echo e($slot); ?>

<?php /**PATH D:\Project\My Project\laravel\eprocurement.rmtdevbase.my.id\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>